"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tomp3 = exports.convertfile = void 0;
const ffmpeg_1 = __importDefault(require("@ffmpeg-installer/ffmpeg"));
const { path } = ffmpeg_1.default;
const fluent_ffmpeg_1 = __importDefault(require("fluent-ffmpeg"));
fluent_ffmpeg_1.default.setFfmpegPath(path);
async function convertfile(path) {
    return new Promise((resolve, reject) => {
        (0, fluent_ffmpeg_1.default)(path)
            .outputFormat('s16le')
            .audioFrequency(16000)
            .outputOptions('-acodec pcm_s16le')
            .audioChannels(1)
            .duration(10)
            .output('node_shazam_temp.pcm')
            .on('end', () => {
            try {
                resolve(undefined);
            }
            catch (error) {
                reject(error);
            }
        })
            .on('error', reject)
            .run();
    });
}
exports.convertfile = convertfile;
async function tomp3(path) {
    return new Promise((resolve, reject) => {
        (0, fluent_ffmpeg_1.default)(path)
            .output('node_shazam_temp.mp3')
            .on('end', () => {
            try {
                resolve(undefined);
            }
            catch (error) {
                reject(error);
            }
        })
            .on('error', reject)
            .run();
    });
}
exports.tomp3 = tomp3;
