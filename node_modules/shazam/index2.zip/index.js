// Importa a biblioteca 'node-shazam'
const { Shazam } = require('node-shazam');

// Cria uma instância do Shazam
const shazam = new Shazam();

async function identificarMusica() {
    try {
        // Caminho do arquivo de áudio
        const filePath = 'musica.mp3';  // Substitua pelo caminho correto do arquivo
        
        // Usa o método fromFilePath para reconhecer a música no arquivo
        const resultado = await shazam.fromFilePath(filePath, false, 'en');
        
        // Exibe os resultados da identificação da música
        console.log('Resultado da identificação:', resultado);
        
        if (resultado && resultado.track) {
            console.log('Música encontrada:', resultado.track.title);  // Título da música
            console.log('Artista:', resultado.track.subtitle);  // Artista da música
            console.log('Álbum:', resultado.track.album.title);  // Álbum da música
        } else {
            console.log('Nenhuma música encontrada no arquivo.');
        }
    } catch (error) {
        console.error('Erro ao identificar a música:', error);  // Trata o erro
    }
}

async function buscarMelhoresFaixas() {
    try {
        // Obtém as melhores faixas globalmente
        const topTracks = await shazam.top_tracks_global('en-US', 'GB', '10', '0');
        
        console.log('Melhores faixas globalmente:', topTracks);
    } catch (error) {
        console.error('Erro ao buscar as melhores faixas:', error);
    }
}

// Executa a identificação de música
identificarMusica();

// Executa a busca das melhores faixas
buscarMelhoresFaixas();