const { Shazam } = require('node-shazam');
const shazam = new Shazam();  // Cria uma instância do Shazam

async function identificarMusicaPorLetra() {
    try {
        console.log('Iniciando a busca pela música...');

        // 1. Busca usando letras da música
        let resultado = await shazam.search_music('en-US', 'US', 'me gustas tu', '1', '0');
        console.log('Resultado da busca por letras:', JSON.stringify(resultado, null, 2));

        // Verifica se a busca por letras trouxe algum resultado
        if (resultado && resultado.tracks && resultado.tracks.hits && resultado.tracks.hits.length > 0) {
            const track = resultado.tracks.hits[0].track;
            console.log('Música encontrada (por letras):', track.title);
            console.log('Artista:', track.subtitle);
            console.log('Álbum:', track.album.title);
        } else {
            console.log('Nenhuma música encontrada por letras. Tentando outras buscas...');
            
            // 2. Busca por nome de música (sem letras)
            resultado = await shazam.search_music('en-US', 'US', 'Never Gonna Give You Up', '1', '0');
            console.log('Resultado da busca por nome de música:', JSON.stringify(resultado, null, 2));
            
            if (resultado && resultado.tracks && resultado.tracks.hits && resultado.tracks.hits.length > 0) {
                const track = resultado.tracks.hits[0].track;
                console.log('Música encontrada (por nome):', track.title);
                console.log('Artista:', track.subtitle);
                console.log('Álbum:', track.album.title);
            } else {
                console.log('Nenhuma música encontrada por nome. Tentando busca por top tracks...');
                
                // 3. Busca pelos top tracks globais
                resultado = await shazam.top_tracks_global('en-US', 'GB', '10', '0');
                console.log('Resultado dos top tracks globais:', JSON.stringify(resultado, null, 2));
                
                if (resultado && resultado.tracks && resultado.tracks.hits && resultado.tracks.hits.length > 0) {
                    const track = resultado.tracks.hits[0].track;
                    console.log('Música encontrada (por top global):', track.title);
                    console.log('Artista:', track.subtitle);
                    console.log('Álbum:', track.album.title);
                } else {
                    console.log('Nenhuma música encontrada nos top tracks globais.');
                }
            }
        }

    } catch (error) {
        console.error('Erro ao buscar a música:', error);  // Trata o erro
    }
}

identificarMusicaPorLetra();  // Chama a função para buscar a música